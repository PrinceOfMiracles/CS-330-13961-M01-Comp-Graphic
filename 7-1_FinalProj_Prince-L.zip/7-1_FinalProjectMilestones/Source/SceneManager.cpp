///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <cmath>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_TextureOverlayValueName = "overlayTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseTextureOverlayName = "bUseTextureOverlay";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetShaderTextureOverlay()
 *
 *  This method is used for enabling or disabling a second
 *  overlay texture.  It is used as the complex texturing
 *  technique for the watch dial label/details.
 ***********************************************************/
void SceneManager::SetShaderTextureOverlay(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		if (textureTag.size() > 0)
		{
			m_pShaderManager->setIntValue(g_UseTextureOverlayName, true);

			int textureID = -1;
			textureID = FindTextureSlot(textureTag);
			m_pShaderManager->setSampler2DValue(g_TextureOverlayValueName, textureID);
		}
		else
		{
			m_pShaderManager->setIntValue(g_UseTextureOverlayName, false);
		}
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/




/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads the texture image files used in the
 *  watch scene.  Each texture receives a simple tag name so
 *  it can be selected before drawing each 3D shape.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// Dark tabletop texture for the required scene plane.
	bReturn = CreateGLTexture("textures/dark_desktop_texture.jpg", "desktop");

	// Student-created 1024x1024 textures for the additional final-project objects.
	bReturn = CreateGLTexture("textures/red_esd_mat_texture.jpg", "esd_mat");
	bReturn = CreateGLTexture("textures/black_toolbox_texture.jpg", "toolbox");

	// Tiled strap texture used on the watch band pieces.
	bReturn = CreateGLTexture("textures/black_leather_texture.jpg", "leather");

	// Brushed metal textures for the case, lugs, crown, hands, and buckle.
	bReturn = CreateGLTexture("textures/brushed_gold_texture.jpg", "gold");
	bReturn = CreateGLTexture("textures/brushed_silver_texture.jpg", "silver");

	// Dark dial texture used on the watch face.
	bReturn = CreateGLTexture("textures/dark_watch_dial_texture.jpg", "dial");

	// Transparent dial overlay used as the complex texture overlay technique.
	bReturn = CreateGLTexture("textures/watch_dial_overlay.png", "dial_overlay");

	// Bind all loaded textures to OpenGL texture units so they can be used later.
	BindGLTextures();
}


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines how each material reflects the lights.
 *  The values are tuned so the textured watch stays visible
 *  while the metal and plane still show light response.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Clear first so the scene is safe if preparation is called again.
	m_objectMaterials.clear();

	OBJECT_MATERIAL desktopMaterial;
	desktopMaterial.diffuseColor = glm::vec3(0.80f, 0.80f, 0.80f);
	desktopMaterial.specularColor = glm::vec3(0.16f, 0.16f, 0.16f);
	desktopMaterial.shininess = 8.0f;
	desktopMaterial.tag = "desktop_plane";
	m_objectMaterials.push_back(desktopMaterial);

	OBJECT_MATERIAL leatherMaterial;
	leatherMaterial.diffuseColor = glm::vec3(0.72f, 0.72f, 0.74f);
	leatherMaterial.specularColor = glm::vec3(0.06f, 0.06f, 0.07f);
	leatherMaterial.shininess = 5.0f;
	leatherMaterial.tag = "leather_band";
	m_objectMaterials.push_back(leatherMaterial);

	OBJECT_MATERIAL goldMaterial;
	goldMaterial.diffuseColor = glm::vec3(1.00f, 0.88f, 0.55f);
	goldMaterial.specularColor = glm::vec3(0.90f, 0.78f, 0.42f);
	goldMaterial.shininess = 64.0f;
	goldMaterial.tag = "polished_gold";
	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL silverMaterial;
	silverMaterial.diffuseColor = glm::vec3(0.82f, 0.82f, 0.82f);
	silverMaterial.specularColor = glm::vec3(0.88f, 0.88f, 0.88f);
	silverMaterial.shininess = 72.0f;
	silverMaterial.tag = "brushed_silver";
	m_objectMaterials.push_back(silverMaterial);

	OBJECT_MATERIAL dialMaterial;
	dialMaterial.diffuseColor = glm::vec3(0.70f, 0.70f, 0.70f);
	dialMaterial.specularColor = glm::vec3(0.22f, 0.24f, 0.26f);
	dialMaterial.shininess = 22.0f;
	dialMaterial.tag = "watch_dial";
	m_objectMaterials.push_back(dialMaterial);

	OBJECT_MATERIAL glassHighlightMaterial;
	glassHighlightMaterial.diffuseColor = glm::vec3(0.60f, 0.72f, 0.84f);
	glassHighlightMaterial.specularColor = glm::vec3(0.95f, 0.95f, 0.95f);
	glassHighlightMaterial.shininess = 96.0f;
	glassHighlightMaterial.tag = "glass_highlight";
	m_objectMaterials.push_back(glassHighlightMaterial);

	OBJECT_MATERIAL esdRubberMaterial;
	esdRubberMaterial.diffuseColor = glm::vec3(0.86f, 0.92f, 1.00f);
	esdRubberMaterial.specularColor = glm::vec3(0.05f, 0.07f, 0.09f);
	esdRubberMaterial.shininess = 5.0f;
	esdRubberMaterial.tag = "esd_rubber";
	m_objectMaterials.push_back(esdRubberMaterial);

	OBJECT_MATERIAL toolboxMaterial;
	toolboxMaterial.diffuseColor = glm::vec3(0.82f, 0.82f, 0.84f);
	toolboxMaterial.specularColor = glm::vec3(0.16f, 0.16f, 0.18f);
	toolboxMaterial.shininess = 12.0f;
	toolboxMaterial.tag = "toolbox_plastic";
	m_objectMaterials.push_back(toolboxMaterial);

	OBJECT_MATERIAL brassMaterial;
	brassMaterial.diffuseColor = glm::vec3(0.94f, 0.78f, 0.42f);
	brassMaterial.specularColor = glm::vec3(0.72f, 0.58f, 0.28f);
	brassMaterial.shininess = 34.0f;
	brassMaterial.tag = "brass_metal";
	m_objectMaterials.push_back(brassMaterial);

	OBJECT_MATERIAL matteBlackMaterial;
	matteBlackMaterial.diffuseColor = glm::vec3(0.08f, 0.08f, 0.08f);
	matteBlackMaterial.specularColor = glm::vec3(0.01f, 0.01f, 0.01f);
	matteBlackMaterial.shininess = 2.0f;
	matteBlackMaterial.tag = "matte_black";
	m_objectMaterials.push_back(matteBlackMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method adds the final-project lighting to the full four-object
 *  scene. Module 6 feedback noted that the plane was too dark and
 *  unevenly lit, so the final scene combines a broad directional fill
 *  with three point lights spread across the ESD mat and objects.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable the Phong lighting calculations in the fragment shader.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// A low-intensity directional light provides an even base across the
	// entire plane.  This prevents the tabletop and strap from disappearing
	// into shadow while still preserving the black tabletop appearance.
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.20f, -1.00f, -0.25f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.18f, 0.18f, 0.18f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.34f, 0.34f, 0.34f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.16f, 0.16f, 0.16f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// The camera-attached spotlight is not needed for this tabletop scene.
	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	// Main neutral key light above the center of the four-object arrangement.
	m_pShaderManager->setVec3Value("pointLights[0].position", 0.2f, 5.8f, 3.6f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.07f, 0.07f, 0.07f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.58f, 0.58f, 0.56f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.46f, 0.46f, 0.44f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Warm left-side accent adds natural highlights to the gold case without
	// producing the large bright patch that appeared in the Module 6 scene.
	m_pShaderManager->setVec3Value("pointLights[1].position", -3.8f, 4.2f, 1.6f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.025f, 0.020f, 0.012f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.30f, 0.24f, 0.15f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.50f, 0.40f, 0.24f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// Cool fill from the opposite side softens the remaining shadows and
	// separates the dark leather band from the black tabletop.
	m_pShaderManager->setVec3Value("pointLights[2].position", 3.8f, 4.5f, -2.0f);
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.035f, 0.040f, 0.050f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.30f, 0.34f, 0.40f);
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.24f, 0.28f, 0.34f);
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);

	// Keep the final available point-light slot disabled.
	m_pShaderManager->setBoolValue("pointLights[3].bActive", false);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load texture images, define materials, and configure lights once before rendering.
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// Each mesh only needs to be loaded once, even if it is drawn many times.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh(0.04f);
}

/***********************************************************
 *  RenderESDMat()
 *
 *  Draws the blue anti-static work mat as a thin textured box.
 *  A small metal grounding snap is included as part of the object.
 ***********************************************************/
void SceneManager::RenderESDMat()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Main blue rubber ESD mat. It sits slightly above the black desktop.
	scaleXYZ = glm::vec3(6.4f, 0.06f, 4.8f);
	positionXYZ = glm::vec3(0.0f, 0.03f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(3.0f, 2.0f);
	SetShaderTexture("esd_mat");
	SetShaderMaterial("esd_rubber");
	m_basicMeshes->DrawBoxMesh();

	// Metal grounding snap in the upper-left corner of the mat.
	scaleXYZ = glm::vec3(0.09f, 0.035f, 0.09f);
	positionXYZ = glm::vec3(-2.85f, 0.065f, 1.95f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("silver");
	SetShaderMaterial("brushed_silver");
	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  RenderToolbox()
 *
 *  Builds a compact black tool case from box primitives. The lid,
 *  body, handle, and silver latches are grouped to read as one object.
 ***********************************************************/
void SceneManager::RenderToolbox()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	const glm::vec3 toolboxCenter = glm::vec3(2.05f, 0.0f, 0.72f);

	// Main textured toolbox body.
	scaleXYZ = glm::vec3(1.85f, 0.53f, 1.15f);
	positionXYZ = glm::vec3(toolboxCenter.x, 0.325f, toolboxCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 1.5f);
	SetShaderTexture("toolbox");
	SetShaderMaterial("toolbox_plastic");
	m_basicMeshes->DrawBoxMesh();

	// Slightly wider lid gives the case a recognizable lip.
	scaleXYZ = glm::vec3(1.95f, 0.15f, 1.22f);
	positionXYZ = glm::vec3(toolboxCenter.x, 0.625f, toolboxCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderTexture("toolbox");
	SetShaderMaterial("toolbox_plastic");
	m_basicMeshes->DrawBoxMesh();

	// Handle: two uprights and a top grip.
	scaleXYZ = glm::vec3(0.11f, 0.34f, 0.13f);
	positionXYZ = glm::vec3(toolboxCenter.x - 0.34f, 0.82f, toolboxCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("toolbox");
	SetShaderMaterial("toolbox_plastic");
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(toolboxCenter.x + 0.34f, 0.82f, toolboxCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.78f, 0.11f, 0.13f);
	positionXYZ = glm::vec3(toolboxCenter.x, 0.96f, toolboxCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// Two silver latches on the front face help separate the black case
	// from the tabletop and make the model more recognizable.
	for (int i = 0; i < 2; ++i)
	{
		float latchX = toolboxCenter.x + ((i == 0) ? -0.48f : 0.48f);
		scaleXYZ = glm::vec3(0.18f, 0.22f, 0.055f);
		positionXYZ = glm::vec3(latchX, 0.47f, toolboxCenter.z + 0.60f);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderTexture("silver");
		SetShaderMaterial("brushed_silver");
		m_basicMeshes->DrawBoxMesh();
	}
}

/***********************************************************
 *  RenderBulletOpener()
 *
 *  Creates the .50-cal-style bottle opener as one continuous brass
 *  object. A cylinder, tapered cylinder, cone, and attached opener ring
 *  are aligned and overlapped so the pieces do not appear separated.
 ***********************************************************/
void SceneManager::RenderBulletOpener()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	const float bulletAngle = -18.0f;
	const float bulletRadians = glm::radians(bulletAngle);
	const glm::vec3 direction = glm::normalize(glm::vec3(
		sinf(bulletRadians), 0.0f, cosf(bulletRadians)));
	const glm::vec3 start = glm::vec3(-2.45f, 0.245f, -0.92f);

	const float bodyLength = 0.82f;
	const float shoulderLength = 0.34f;
	const float tipLength = 0.30f;

	// Brass cartridge body. Cylinder geometry extends from local y=0 to y=1,
	// so the next component starts exactly at the transformed endpoint.
	scaleXYZ = glm::vec3(0.18f, bodyLength, 0.18f);
	positionXYZ = start;
	SetTransformations(scaleXYZ, 90.0f, bulletAngle, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 2.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("brass_metal");
	m_basicMeshes->DrawCylinderMesh();

	// Tapered shoulder starts at the end of the cartridge body.
	positionXYZ = start + direction * bodyLength;
	scaleXYZ = glm::vec3(0.18f, shoulderLength, 0.18f);
	SetTransformations(scaleXYZ, 90.0f, bulletAngle, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("brass_metal");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Pointed tip continues directly from the tapered shoulder.
	positionXYZ = start + direction * (bodyLength + shoulderLength);
	scaleXYZ = glm::vec3(0.11f, tipLength, 0.11f);
	SetTransformations(scaleXYZ, 90.0f, bulletAngle, 0.0f, positionXYZ);
	SetShaderTexture("gold");
	SetShaderMaterial("brass_metal");
	m_basicMeshes->DrawConeMesh();

	// Simple brass rear cap keeps the bullet readable without extra gray
	// opener pieces appearing behind it in the top-down view.
	glm::vec3 rearCapCenter = start - direction * 0.06f;
	positionXYZ = glm::vec3(rearCapCenter.x, 0.245f, rearCapCenter.z);
	scaleXYZ = glm::vec3(0.19f, 0.04f, 0.19f);
	SetTransformations(scaleXYZ, 90.0f, bulletAngle, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("brass_metal");
	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Declare the variables used to scale, rotate, and position each shape.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Module 7 final-project scene. Four completed real-world objects are shown:
	// an ESD mat, black toolbox, wristwatch, and .50-cal-style bottle opener.
	// The watch remains the primary complex multi-primitive object.
	const glm::vec3 watchCenter = glm::vec3(0.0f, 0.0f, -0.15f);

	/******************************************************************/
	// Dark desktop surface used as the required scene plane. The UV scale
	// tiles the texture so the surface does not look stretched.
	scaleXYZ = glm::vec3(7.0f, 1.0f, 5.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(5.0f, 4.0f);
	SetShaderTexture("desktop");
	SetShaderMaterial("desktop_plane");
	m_basicMeshes->DrawPlaneMesh();
	/******************************************************************/

	/******************************************************************/
	// Additional completed objects required by the final-project rubric.
	// They are rendered through custom helper functions to keep RenderScene()
	// organized and make each object easy to revise independently.
	RenderESDMat();
	RenderToolbox();
	RenderBulletOpener();
	/******************************************************************/

	/******************************************************************/
	// WATCH STRAP: leather texture is tiled along the length of the strap
	// so the band has more detail instead of a flat black color.

	// Lower strap section.
	scaleXYZ = glm::vec3(0.32f, 0.045f, 0.95f);
	positionXYZ = glm::vec3(watchCenter.x, 0.13f, watchCenter.z - 1.10f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	// Complex texturing technique: draw the strap box one side at a time.
	// The top/front/back use the leather texture, while the edge and bottom
	// faces use the darker desktop texture to create a two-material band.
	SetTextureUVScale(1.0f, 4.0f);
	SetShaderTexture("leather");
	SetShaderMaterial("leather_band");
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_top);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_front);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_back);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("desktop");
	SetShaderMaterial("desktop_plane");
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_left);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_right);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_bottom);

	// Rounded lower strap end.
	scaleXYZ = glm::vec3(0.32f, 0.035f, 0.32f);
	positionXYZ = glm::vec3(watchCenter.x, 0.135f, watchCenter.z - 1.95f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("leather");
	SetShaderMaterial("leather_band");
	m_basicMeshes->DrawCylinderMesh();

	// Upper strap section.
	scaleXYZ = glm::vec3(0.32f, 0.045f, 0.88f);
	positionXYZ = glm::vec3(watchCenter.x, 0.13f, watchCenter.z + 1.03f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	// Complex texturing technique: draw the strap box one side at a time.
	// The top/front/back use the leather texture, while the edge and bottom
	// faces use the darker desktop texture to create a two-material band.
	SetTextureUVScale(1.0f, 4.0f);
	SetShaderTexture("leather");
	SetShaderMaterial("leather_band");
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_top);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_front);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_back);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("desktop");
	SetShaderMaterial("desktop_plane");
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_left);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_right);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_bottom);

	// Rounded upper strap end near the buckle.
	scaleXYZ = glm::vec3(0.32f, 0.035f, 0.32f);
	positionXYZ = glm::vec3(watchCenter.x, 0.135f, watchCenter.z + 1.78f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("leather");
	SetShaderMaterial("leather_band");
	m_basicMeshes->DrawCylinderMesh();

	// Strap holes make the band read more like a watch band instead of a plain box.
	for (int i = 0; i < 5; ++i)
	{
		scaleXYZ = glm::vec3(0.045f, 0.012f, 0.045f);
		positionXYZ = glm::vec3(watchCenter.x, 0.175f, watchCenter.z - 0.80f - (i * 0.22f));
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.006f, 0.006f, 0.008f, 1.0f);
		SetShaderMaterial("matte_black");
		m_basicMeshes->DrawCylinderMesh();
	}

	// Metal buckle and cross pin at the top of the strap.
	scaleXYZ = glm::vec3(0.48f, 0.035f, 0.055f);
	positionXYZ = glm::vec3(watchCenter.x, 0.19f, watchCenter.z + 2.05f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("silver");
	SetShaderMaterial("brushed_silver");
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.055f, 0.035f, 0.30f);
	positionXYZ = glm::vec3(watchCenter.x - 0.24f, 0.19f, watchCenter.z + 1.92f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("silver");
	SetShaderMaterial("brushed_silver");
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(watchCenter.x + 0.24f, 0.19f, watchCenter.z + 1.92f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("silver");
	SetShaderMaterial("brushed_silver");
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/

	/******************************************************************/
	// WATCH CASE: gold texture is used on the metal case pieces. Different
	// textures are applied to different shapes to keep the object cohesive.

	// Four lugs connect the strap to the watch case.
	scaleXYZ = glm::vec3(0.18f, 0.08f, 0.20f);
	positionXYZ = glm::vec3(watchCenter.x - 0.32f, 0.20f, watchCenter.z + 0.63f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -8.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(watchCenter.x + 0.32f, 0.20f, watchCenter.z + 0.63f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 8.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(watchCenter.x - 0.32f, 0.20f, watchCenter.z - 0.63f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 8.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(watchCenter.x + 0.32f, 0.20f, watchCenter.z - 0.63f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -8.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawBoxMesh();

	// Main round watch case.
	scaleXYZ = glm::vec3(0.62f, 0.10f, 0.62f);
	positionXYZ = glm::vec3(watchCenter.x, 0.20f, watchCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawCylinderMesh();

	// Raised outer rim.
	scaleXYZ = glm::vec3(0.62f, 0.055f, 0.62f);
	positionXYZ = glm::vec3(watchCenter.x, 0.32f, watchCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawTorusMesh();

	// Inner dark face/dial.
	scaleXYZ = glm::vec3(0.47f, 0.030f, 0.47f);
	positionXYZ = glm::vec3(watchCenter.x, 0.335f, watchCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	// Complex texturing technique: apply a transparent overlay texture
	// on top of the base dial texture, similar to adding a label.
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("dial");
	SetShaderMaterial("watch_dial");
	SetShaderTextureOverlay("dial_overlay");
	m_basicMeshes->DrawCylinderMesh();
	// Disable overlay so it is not applied to the remaining watch parts.
	SetShaderTextureOverlay("");

	// Thin blue-gray glass highlight across the dial.
	scaleXYZ = glm::vec3(0.34f, 0.010f, 0.055f);
	positionXYZ = glm::vec3(watchCenter.x - 0.10f, 0.37f, watchCenter.z + 0.12f);
	SetTransformations(scaleXYZ, 0.0f, -24.0f, 0.0f, positionXYZ);
	SetShaderColor(0.38f, 0.52f, 0.64f, 0.65f);
	SetShaderMaterial("glass_highlight");
	m_basicMeshes->DrawBoxMesh();

	// Side crown on the case.
	scaleXYZ = glm::vec3(0.075f, 0.18f, 0.075f);
	positionXYZ = glm::vec3(watchCenter.x + 0.74f, 0.27f, watchCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -90.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawCylinderMesh();
	/******************************************************************/

	/******************************************************************/
	// WATCH FACE DETAILS: hour markers, hands, and center pin.

	// Twelve raised hour markers make the dial more accurate and detailed.
	for (int i = 0; i < 12; ++i)
	{
		float markerDegrees = i * 30.0f;
		float markerRadians = glm::radians(markerDegrees);
		float markerRadius = 0.36f;

		scaleXYZ = glm::vec3(0.018f, 0.012f, 0.075f);
		positionXYZ = glm::vec3(
			watchCenter.x + sinf(markerRadians) * markerRadius,
			0.385f,
			watchCenter.z + cosf(markerRadians) * markerRadius);

		SetTransformations(scaleXYZ, 0.0f, markerDegrees, 0.0f, positionXYZ);
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderTexture("gold");
		SetShaderMaterial("polished_gold");
		m_basicMeshes->DrawBoxMesh();
	}

	// Minute hand pointing close to twelve o'clock.
	scaleXYZ = glm::vec3(0.025f, 0.012f, 0.235f);
	positionXYZ = glm::vec3(watchCenter.x, 0.405f, watchCenter.z + 0.115f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("silver");
	SetShaderMaterial("brushed_silver");
	m_basicMeshes->DrawBoxMesh();

	// Shorter hour hand angled to make the face look functional.
	float handDegrees = -48.0f;
	float handRadians = glm::radians(handDegrees);
	float hourHandOffset = 0.080f;
	scaleXYZ = glm::vec3(0.032f, 0.014f, 0.165f);
	positionXYZ = glm::vec3(
		watchCenter.x + sinf(handRadians) * hourHandOffset,
		0.415f,
		watchCenter.z + cosf(handRadians) * hourHandOffset);
	SetTransformations(scaleXYZ, 0.0f, handDegrees, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("silver");
	SetShaderMaterial("brushed_silver");
	m_basicMeshes->DrawBoxMesh();

	// Center pin that covers the joints of the two hands.
	scaleXYZ = glm::vec3(0.050f, 0.012f, 0.050f);
	positionXYZ = glm::vec3(watchCenter.x, 0.430f, watchCenter.z);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("polished_gold");
	m_basicMeshes->DrawCylinderMesh();
	/******************************************************************/
}
