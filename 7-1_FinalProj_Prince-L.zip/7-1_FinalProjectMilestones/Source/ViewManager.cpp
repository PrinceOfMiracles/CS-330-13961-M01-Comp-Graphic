///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// The following variable controls which projection mode is active.
	// false = perspective view, true = orthographic view.
	bool bOrthographicProjection = false;

	// These flags keep P and O from toggling repeatedly while the key is held.
	bool gPKeyPressed = false;
	bool gOKeyPressed = false;

	// Orthographic view settings are wide enough to show all four completed
	// objects and preserve the 1000x800 window aspect ratio.
	const float ORTHO_LEFT = -4.5f;
	const float ORTHO_RIGHT = 4.5f;
	const float ORTHO_BOTTOM = -3.6f;
	const float ORTHO_TOP = 3.6f;

	// Include the ESD mat and tabletop instead of clipping the scene plane.
	const float ORTHO_NEAR = 0.1f;
	const float ORTHO_FAR = 20.0f;

	// Reset the camera to the same starting position every time the view is restored.
	void ResetCameraStartView()
	{
		if (NULL != g_pCamera)
		{
			g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
			g_pCamera->WorldUp = glm::vec3(0.0f, 1.0f, 0.0f);
			g_pCamera->Yaw = -90.0f;
			g_pCamera->Pitch = -14.0f;
			g_pCamera->Zoom = 80.0f;
			g_pCamera->MovementSpeed = 10.0f;

			// Recalculate the camera direction vectors after resetting yaw and pitch.
			g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
		}

		// Prevent a sudden mouse jump after changing projection modes.
		gFirstMouse = true;
	}
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	ResetCameraStartView();
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse wheel scrolling events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// when the first mouse move event is received, this needs to be recorded so that
	// all subsequent mouse moves can correctly calculate the X position offset and Y
	// position offset for proper operation
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// calculate the X offset and Y offset values for moving the 3D camera accordingly
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // reversed since y-coordinates go from bottom to top

	// set the current positions into the last position variables
	gLastX = xMousePos;
	gLastY = yMousePos;

	// Orthographic projection is a fixed inspection view, so mouse movement
	// should not change the saved perspective camera direction.
	if (bOrthographicProjection)
	{
		return;
	}

	// move the 3D camera according to the calculated offsets
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is moved. The scroll wheel changes
 *  the camera movement speed so the user can travel slower
 *  or faster through the scene.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// Adjust camera speed only in perspective view. Orthographic view is fixed
	// so the perspective camera speed is not accidentally changed there.
	if ((NULL != g_pCamera) && (false == bOrthographicProjection))
	{
		g_pCamera->ProcessMouseScroll((float)yOffset);
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// P switches the display back to perspective projection and restores
	// the camera to the original starting view.
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS && gPKeyPressed == false)
	{
		bOrthographicProjection = false;
		ResetCameraStartView();
		gPKeyPressed = true;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_RELEASE)
	{
		gPKeyPressed = false;
	}

	// O switches the display to orthographic projection. The perspective
	// camera is also reset so returning with P starts from a clean view.
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS && gOKeyPressed == false)
	{
		bOrthographicProjection = true;
		ResetCameraStartView();
		gOKeyPressed = true;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_RELEASE)
	{
		gOKeyPressed = false;
	}

	// Do not allow camera movement in orthographic mode. This keeps the
	// orthographic view fixed and prevents it from changing perspective view.
	if (bOrthographicProjection)
	{
		return;
	}

	// WASD controls horizontal and depth movement through the scene.
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// Q and E add vertical camera movement.
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// This value is passed to the shader for view-dependent lighting.
	glm::vec3 viewPosition = g_pCamera->Position;

	// Orthographic projection uses a fixed top-down inspection view. The camera
	// is placed above the scene so all four objects remain visible without
	// perspective distortion.
	if (bOrthographicProjection)
	{
		glm::vec3 orthoCameraPosition = glm::vec3(0.0f, 8.0f, 0.0f);
		viewPosition = orthoCameraPosition;

		view = glm::lookAt(
			orthoCameraPosition,
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, -1.0f));

		// The wider clipping range keeps the mat, tabletop, and raised objects visible.
		projection = glm::ortho(ORTHO_LEFT, ORTHO_RIGHT, ORTHO_BOTTOM, ORTHO_TOP, ORTHO_NEAR, ORTHO_FAR);
	}
	else
	{
		view = g_pCamera->GetViewMatrix();
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f,
			100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", viewPosition);
	}
}